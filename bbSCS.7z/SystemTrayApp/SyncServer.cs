﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;

namespace SystemTrayApp
{
    public class SyncServer
    {
        public SyncServer()
        {
            var listener = new HttpListener();

           // listener.Prefixes.Add("http://localhost:8081/");
            listener.Prefixes.Add("http://127.0.0.1:8008/");

            listener.Start();

       
                try
                {
                    var context = listener.GetContext(); //Block until a connection comes in
                    context.Response.StatusCode = 200;
                    context.Response.SendChunked = true;

                    int totalTime = 0;
                
                    

                }
                catch (Exception)
                {
                    // Client disconnected or some other error - ignored for this example
                }
            }
        
    }
}
